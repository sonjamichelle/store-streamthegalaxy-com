{*
	<note description="shameless guilt trip">
	A vast amount of time has gone into the development of CubeCart.
	You could maybe.. just possibly.. leave a little link back to us? ♥ x 
	</note>
*}
 <div style="text-align: center; margin: 10px; font-size: 80%;"><p><a href="http://www.cubecart.com" target="_blank">eCommerce</a> by CubeCart</p></div>